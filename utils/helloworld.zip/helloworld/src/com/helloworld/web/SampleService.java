package com.helloworld.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import xeno.remoting.bind.RemoteProxy;
import xeno.remoting.bind.WebMethod;
import xeno.remoting.web.Browser;
import xeno.remoting.web.JavaScriptCallback;

import com.helloworld.ui.Account;
import com.helloworld.ui.Organization;

@RemoteProxy
public class SampleService {

	@WebMethod
	public Organization getOrganization(Account acct, String auth) {
		Account acct1 = new Account();
		acct1.setId(9);
		acct1.setName("Jane Lin");

		Account acct2 = new Account();
		acct2.setId(7);
		acct2.setName("Tim Zhang");

		List<Account> accounts = new ArrayList<Account>();
		accounts.add(acct1);
		accounts.add(acct2);
		accounts.add(acct);

		Organization organization = new Organization();
		organization.setCode("org_a_" + auth);
		organization.setName("Organization A");
		organization.setAccounts(accounts);

		return organization;
	}

	@WebMethod
	public void performCallback() {
		Account acct1 = new Account();
		acct1.setId(18);
		acct1.setName("Jeff Wang");

		Account acct2 = new Account();
		acct2.setId(21);
		acct2.setName("Bob Qiu");

		List<Account> accounts = new ArrayList<Account>();
		accounts.add(acct1);
		accounts.add(acct2);

		Organization organization = new Organization();
		organization.setCode("org_b");
		organization.setName("Organization B");
		organization.setAccounts(accounts);

		long timestamp = new Date().getTime();

		JavaScriptCallback callback = Browser.withPage("/reverse_ajax.jsp");
		callback.invoke("updateOrganization", organization, timestamp);
	}
}
